package com.koreait.day2.repository;

import com.koreait.day2.Day2ApplicationTests;
import com.koreait.day2.model.entity.Item;
import com.koreait.day2.model.entity.Partner;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.Optional;

public class PartnerRepositoryTest extends Day2ApplicationTests {

    @Autowired
    private PartnerRepository partnerRepository;

    @Test
    public void create(){
        Partner partner = Partner.builder()
                .name("lg베스트샵")
                .status("사용중")
                .address("서울시 관악구")
                .callCenter("070-4444-4444")
                .businessNumber("444-44-444444")
                .ceoName("오지환")
                .regDate(LocalDateTime.now())
                .categoryId(5L)
                .build();
        Partner newPartner = partnerRepository.save(partner);

    }

    @Test
    public void read(){
        Optional<Partner> partner = partnerRepository.findFirstByNameOrderByIdDesc("lg베스트샵");
        if(partner.isPresent()){
            System.out.println("데이터가 존재합니다.");
        }else{
            System.out.println("데이터가 존재하지 않습니다.");
        }
    }
    @Test
    public void update(){
        Optional<Partner> partner = partnerRepository.findById(41L);
        partner.ifPresent(selectPartner ->{
            selectPartner.setName("LG");
            partnerRepository.save(selectPartner);
        });
    }
}
