package com.koreait.day2.repository;

import com.koreait.day2.Day2ApplicationTests;
import com.koreait.day2.model.entity.Item;
import com.koreait.day2.model.entity.OrderDetail;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

public class OrderDetailRepositoryTest extends Day2ApplicationTests {

    @Autowired
    private OrderDetailRepository orderDetailRepository;

    @Test
    public void create(){
        OrderDetail orderDetail = OrderDetail.builder()
                .status("결제완료")
                .quantity(1)  //수량
                .totalPrice(BigDecimal.valueOf(5000000))
                .regDate(LocalDateTime.now())
                .itemId(21L)
                .orderGroupId(2L)
                .build();
        OrderDetail newOrderDetail = orderDetailRepository.save(orderDetail);
    }

    @Test
    public void read(){
        Optional<OrderDetail> orderDetail = orderDetailRepository.findById(44L);
        if(orderDetail.isPresent()){
            System.out.println("데이터가 존재합니다.");
        }else{
            System.out.println("데이터가 존재하지 않습니다.");
        }
    }
    @Test
    public void update(){
        Optional<OrderDetail> item = orderDetailRepository.findById(44L);
        item.ifPresent(selectItem ->{
            selectItem.setStatus("결제중");
            orderDetailRepository.save(selectItem);
        });
    }

    @Test
    public void delete(){
        Optional<OrderDetail> orderDetail = orderDetailRepository.findByIdAndStatus(44L,"결제중");
        if(orderDetail.isPresent()){//deleteUser.isPresent() : deleteUser 안에 데이터가 들어있니??
            System.out.println("삭제실패");
        }else {
            System.out.println("삭제성공");
        }
    }
}
