package com.koreait.day2.repository;

import com.koreait.day2.Day2ApplicationTests;
import com.koreait.day2.model.entity.UserTb;
import org.springframework.beans.factory.annotation.Autowired;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Optional;

public class UserTbRepositoryTest extends Day2ApplicationTests {
    //Day2ApplicationTests : Junit을 사용하여 테스트 하기 위한 클래스를 상속받음
    @Autowired
    private UserTbRepository userTbRepository;

    @Test
    public void create() {
//방법 1
//        UserTb userTb = new UserTb();
//
//        userTb.setUserid("banana");
//        userTb.setUserpw("1212");
//        userTb.setHp("010-1212-1212");
//        userTb.setEmail("bana@bana.com");
//        userTb.setRegDate(LocalDateTime.now());
//
//        UserTb userTb1 = userTbRepository.save(userTb);

        //방법 2
        UserTb userTb = UserTb.builder()
                .userid("banana")
                .userpw("2222")
                .hp("010-2222-2222")
                .email("banana@banana.com")
                .regDate(LocalDateTime.now())
                .updateDate(LocalDateTime.now())
                .build();
        UserTb newUserTb = userTbRepository.save(userTb);
    }
    @Test //단위 테스트 실행 //셀렉트(조회)
    public void read(){
        // select * from userTb where userid=? //userid를 찾아줄 떄
//        Optional<UserTb> user = userTbRepository.findByUserid("banana");
//        user.ifPresent(selectUserTb -> {
//            System.out.println("userTb : " +selectUserTb);
//            System.out.println("userid : " +selectUserTb.getUserid());
//            System.out.println("userpw : " +selectUserTb.getUserpw());
//            System.out.println("hp : " +selectUserTb.getHp());
//            System.out.println("email : " +selectUserTb.getEmail());
//
//        });
        UserTb user = userTbRepository.findFirstByHpOrderByIdDesc("010-1212-1212");
        if(user != null){
            System.out.println("데이터가 존재합니다");
        }else {
            System.out.println("데이터가 존재하지 않습니다.");
        }
    }
    
    //업데이트(수정)
    @Test
    public void update(){
        Optional<UserTb> user = userTbRepository.findByUserid("banana");
        user.ifPresent(selectUserTb ->{
            selectUserTb.setEmail("banaa@naver.com");
            selectUserTb.setHp("010-9999-9999");
            selectUserTb.setUpdateDate(LocalDateTime.now());
            userTbRepository.save(selectUserTb);
        });
    }
    
    //딜리트(삭제)
    @Test
    public void delete(){
        Optional<UserTb> user = userTbRepository.findByUserid("banana");
        
        user.ifPresent(selectUserTb -> {
            userTbRepository.delete(selectUserTb);
        });
        //다시 한번 검색을 해줌
        Optional<UserTb> deleteUser = userTbRepository.findByUserid("banana");
        if(deleteUser.isPresent()){//deleteUser.isPresent() : deleteUser 안에 데이터가 들어있니??
            System.out.println("삭제실패");
        }else {
            System.out.println("삭제성공");
        }
    }
}
