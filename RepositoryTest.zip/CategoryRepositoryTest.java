package com.koreait.day2.repository;

import com.koreait.day2.Day2ApplicationTests;
import com.koreait.day2.model.entity.Category;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.util.Optional;

public class CategoryRepositoryTest extends Day2ApplicationTests {

    @Autowired
    private CategoryRepository categoryRepository;
    //자동차, 컴퓨터, 가전
    @Test
    public void create(){
        Category category = Category.builder()
                .type("컴퓨터")
                .title("애플 맥프로")
                .regDate(LocalDateTime.now())
                .build();
        Category newCategory = categoryRepository.save(category);
    }

    @Test
    public void read(){
        Optional<Category> category = categoryRepository.findFirstByTypeOrderByIdDesc("컴퓨터");
        if(category.isPresent()){
            System.out.println("데이터가 존재합니다.");
        }else{
            System.out.println("데이터가 존재하지 않습니다.");
        }
    }
    @Test
    public void update(){
        Optional<Category> category = categoryRepository.findById(41L);
        //데이터를 오라클에서 가져와서  category에 저장.(Resultset과 같은 의미)
        category.ifPresent(selectCategory -> {
            selectCategory.setType("애플 맥");
            categoryRepository.save(selectCategory);
        });
    }

    @Test
    public void delete(){
        Optional<Category> category = categoryRepository.findByTypeAndTitle("애플 맥","애플 맥프로");

        category.ifPresent(selectCategory -> {
            categoryRepository.delete(selectCategory);
        });
        Optional<Category> deleteCategory = categoryRepository.findByTypeAndTitle("애플 맥","애플 맥프로");
        if(deleteCategory.isPresent()){
            System.out.println("삭제실패");
        }else {
            System.out.println("삭제성공");
        }


    }
}
