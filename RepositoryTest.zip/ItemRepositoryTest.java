package com.koreait.day2.repository;

import com.koreait.day2.Day2ApplicationTests;
import com.koreait.day2.model.entity.Item;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

public class ItemRepositoryTest extends Day2ApplicationTests {

    @Autowired
    private ItemRepository itemRepository;

    @Test
    public void create(){
        Item item= Item.builder()
                .name("애플 워치")
                .status("판매중")
                .title("워치")
                .content("터치됨")
                .price(BigDecimal.valueOf(5000000))
                .regDate(LocalDateTime.now())
                .partnerId(21L)
                .build();
        Item newItem = itemRepository.save(item);
    }
    @Test
    public void read(){
        Optional<Item> item = itemRepository.findFirstByNameOrderByIdDesc("애플 워치");
        if(item.isPresent()){
            System.out.println("데이터가 존재합니다.");
        }else{
            System.out.println("데이터가 존재하지 않습니다.");
        }
    }

    @Test
    public void update(){
        Optional<Item> item = itemRepository.findById(21L);
        item.ifPresent(selectItem ->{
            selectItem.setTitle("시계");
            itemRepository.save(selectItem);
        });
    }
    @Test
    public void delete(){
        Optional<Item> item = itemRepository.findByIdAndName(21L,"애플 워치");
        if(item.isPresent()){//deleteUser.isPresent() : deleteUser 안에 데이터가 들어있니??
            System.out.println("삭제실패");
        }else {
            System.out.println("삭제성공");
        }
    }
}
