package com.koreait.day2.model.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
//저장시키는 생성자도 자동으로 만들어줌
@AllArgsConstructor
//빈 생성자를 자동으로 만들어줌
@NoArgsConstructor

@Entity //만들어 놓은 테이블과 연결시켜줌
@SequenceGenerator(
        name = "seq_cate", // 내가 지어주고 싶은 이름
        sequenceName = "seq_cate", //오라클 시퀀스 이름
        initialValue = 1,
        allocationSize = 1
)
@Builder
public class Category {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_cate")
    private Long id;
    private String type;
    private String title;
    private LocalDateTime regDate;
    private LocalDateTime updateDate;
}
