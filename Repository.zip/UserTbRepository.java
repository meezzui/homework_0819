package com.koreait.day2.repository;

import com.koreait.day2.model.entity.UserTb;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserTbRepository extends JpaRepository<UserTb,Long>{
    //paRepository<UserTb,Long> : UserTb 클래스를 가져올 거고 타입은 Long형

    // select * from userTb where userid=?
    Optional<UserTb> findByUserid(String userid); //findBy : 해당 필드를 찾아줌
    Optional<UserTb> findByUseridAndAndUserpw(String userid, String userpw);

    //select * from userTb where rownum <=1 order by id desc
    UserTb findFirstByHpOrderByIdDesc(String hp);
}
